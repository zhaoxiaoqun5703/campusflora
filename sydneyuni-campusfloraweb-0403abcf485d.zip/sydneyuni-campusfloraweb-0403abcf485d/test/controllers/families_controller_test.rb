require 'test_helper'

class FamiliesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
