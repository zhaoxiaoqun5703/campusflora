class Family < ActiveRecord::Base
  has_many :species
end
